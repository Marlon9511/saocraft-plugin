# SaoCraft

Ein Sword-Art-Online-inspiriertes Spigot-Plugin für Minecraft. Es nutzt nur eigene
Mechaniken, Farben und Item-Namen – keine Original-Grafiken, Logos oder Texte aus
dem Anime/den Spielen.

## Features

- **Sword Skills**: Schleichen + Rechtsklick mit einem Schwert löst deinen aktuell
  ausgerüsteten Skill aus (Horizontal, Vertical, Sonic Leap, Starburst Stream),
  jeweils mit eigenem Cooldown, Bonus-Schaden, Partikeln und Sound.
- **HP-Balken über dem Kopf**: Jeder Spieler bekommt einen für alle sichtbaren
  Lebensbalken über dem Kopf, der sich live mit der Farbe grün/gelb/rot ändert.
- **Duell-System**: `/duel <spieler>` fordert heraus, `/duel accept` nimmt an.
  Sobald die HP eines Duellanten auf 0 fallen würde, wird das als Niederlage
  gewertet, kein echter Tod – beide werden geheilt und zurückteleportiert.
- **Status-Menü**: `/saomenu` öffnet ein Inventar-GUI im SAO-Stil mit HP, Level,
  ausgerüstetem Skill, allen verfügbaren Skills und Duell-Status.

## Befehle

| Befehl | Beschreibung |
|---|---|
| `/skill list` | Zeigt alle Sword Skills |
| `/skill <horizontal\|vertical\|sonicleap\|starburst>` | Skill ausrüsten |
| `/duel <spieler>` | Duell anfragen |
| `/duel accept` / `/duel decline` / `/duel leave` | Anfrage annehmen/ablehnen/Duell verlassen |
| `/saomenu` (Alias `/status`) | Status-Menü öffnen |

## Bauen

Voraussetzung: Java 17+ und Maven.

```bash
mvn clean package
```

Die fertige `SaoCraft.jar` liegt danach in `target/` und kommt einfach in den
`plugins`-Ordner deines Spigot-/Paper-Servers.

**Hinweis zur Version**: Das Projekt ist gegen Spigot-API 1.21.4 gebaut
(`api-version: '1.21'`). Dank Bukkit-API-Rückwärtskompatibilität läuft das Plugin
auch auf neueren Server-Versionen (aktuell z.B. 26.x). Falls dein Server eine
eigene, neuere `spigot-api`-Koordinate braucht, einfach die Version in der
`pom.xml` anpassen und `BuildTools` für diese Version laufen lassen.

## Erweiterungsideen

- Eigene Skill-Items (z.B. per Rechtsklick auf ein bestimmtes Schwert das passende
  Skill-Set laden)
- Arena-Koordinaten für Duelle statt Teleport zum Mittelpunkt
- Persistenz der ausgerüsteten Skills über einen Neustart hinweg (aktuell nur im RAM)
- Levelsystem mit XP aus Kills, das die Bonus-Schaden-Werte skaliert
