package com.example.saocraft.duel;

import com.example.saocraft.SaoCraftPlugin;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class DuelManager {

    private final SaoCraftPlugin plugin;

    // Wer hat wen zum Duell eingeladen: Ziel-UUID -> Sender-UUID
    private final Map<UUID, UUID> pendingRequests = new HashMap<>();

    // Aktive Duelle: Spieler-UUID -> Gegner-UUID (beidseitig eingetragen)
    private final Map<UUID, UUID> activeDuels = new HashMap<>();

    // Rückkehr-Position vor dem Duell
    private final Map<UUID, Location> returnLocations = new HashMap<>();

    public DuelManager(SaoCraftPlugin plugin) {
        this.plugin = plugin;
    }

    public boolean isInDuel(Player player) {
        return activeDuels.containsKey(player.getUniqueId());
    }

    public Player getOpponent(Player player) {
        UUID opponentId = activeDuels.get(player.getUniqueId());
        return opponentId != null ? plugin.getServer().getPlayer(opponentId) : null;
    }

    public void requestDuel(Player sender, Player target) {
        if (isInDuel(sender) || isInDuel(target)) {
            sender.sendMessage(ChatColor.RED + "Einer von euch ist bereits in einem Duell.");
            return;
        }
        pendingRequests.put(target.getUniqueId(), sender.getUniqueId());
        sender.sendMessage(ChatColor.GOLD + "Duell-Anfrage an " + target.getName() + " gesendet.");
        target.sendMessage(ChatColor.GOLD + sender.getName() + " fordert dich zum Duell heraus! "
                + ChatColor.GREEN + "/duel accept" + ChatColor.GOLD + " oder " + ChatColor.RED + "/duel decline");
    }

    public void acceptDuel(Player target) {
        UUID senderId = pendingRequests.remove(target.getUniqueId());
        if (senderId == null) {
            target.sendMessage(ChatColor.RED + "Keine offene Duell-Anfrage.");
            return;
        }
        Player sender = plugin.getServer().getPlayer(senderId);
        if (sender == null || !sender.isOnline()) {
            target.sendMessage(ChatColor.RED + "Der Herausforderer ist nicht mehr online.");
            return;
        }

        startDuel(sender, target);
    }

    public void declineDuel(Player target) {
        UUID senderId = pendingRequests.remove(target.getUniqueId());
        if (senderId == null) {
            target.sendMessage(ChatColor.RED + "Keine offene Duell-Anfrage.");
            return;
        }
        Player sender = plugin.getServer().getPlayer(senderId);
        target.sendMessage(ChatColor.YELLOW + "Duell abgelehnt.");
        if (sender != null) {
            sender.sendMessage(ChatColor.YELLOW + target.getName() + " hat dein Duell abgelehnt.");
        }
    }

    private void startDuel(Player a, Player b) {
        returnLocations.put(a.getUniqueId(), a.getLocation());
        returnLocations.put(b.getUniqueId(), b.getLocation());

        activeDuels.put(a.getUniqueId(), b.getUniqueId());
        activeDuels.put(b.getUniqueId(), a.getUniqueId());

        // Beide Spieler an einen Punkt zwischen ihnen versetzen, 4 Blöcke auseinander
        Location mid = a.getLocation().clone().add(b.getLocation()).multiply(0.5);
        mid.setWorld(a.getWorld());
        a.teleport(mid.clone().add(2, 0, 0));
        b.teleport(mid.clone().add(-2, 0, 0));

        heal(a);
        heal(b);

        a.sendTitle(ChatColor.RED + "DUELL!", ChatColor.GRAY + "gegen " + b.getName(), 10, 40, 10);
        b.sendTitle(ChatColor.RED + "DUELL!", ChatColor.GRAY + "gegen " + a.getName(), 10, 40, 10);
    }

    private void heal(Player player) {
        double max = player.getAttribute(Attribute.GENERIC_MAX_HEALTH) != null
                ? player.getAttribute(Attribute.GENERIC_MAX_HEALTH).getValue() : 20.0;
        player.setHealth(max);
    }

    /** Beendet das Duell. loser darf null sein (z.B. bei /duel leave ohne klaren Verlierer). */
    public void endDuel(Player a, Player b, Player winner) {
        activeDuels.remove(a.getUniqueId());
        activeDuels.remove(b.getUniqueId());

        Location returnA = returnLocations.remove(a.getUniqueId());
        Location returnB = returnLocations.remove(b.getUniqueId());
        if (returnA != null) a.teleport(returnA);
        if (returnB != null) b.teleport(returnB);

        heal(a);
        heal(b);

        if (winner != null) {
            a.sendTitle(ChatColor.GOLD + (winner.equals(a) ? "SIEG!" : "NIEDERLAGE"), "", 10, 40, 10);
            b.sendTitle(ChatColor.GOLD + (winner.equals(b) ? "SIEG!" : "NIEDERLAGE"), "", 10, 40, 10);
        }
    }

    public void leaveDuel(Player player) {
        Player opponent = getOpponent(player);
        if (opponent == null) {
            player.sendMessage(ChatColor.RED + "Du bist in keinem Duell.");
            return;
        }
        endDuel(player, opponent, opponent);
        opponent.sendMessage(ChatColor.YELLOW + player.getName() + " hat das Duell verlassen.");
    }
}
