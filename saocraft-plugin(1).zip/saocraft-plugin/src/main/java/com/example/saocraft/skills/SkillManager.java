package com.example.saocraft.skills;

import com.example.saocraft.SaoCraftPlugin;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class SkillManager {

    private final SaoCraftPlugin plugin;
    private final Map<UUID, SwordSkillType> equippedSkill = new HashMap<>();
    private final Map<UUID, Long> cooldownExpiry = new HashMap<>();

    public SkillManager(SaoCraftPlugin plugin) {
        this.plugin = plugin;
    }

    public void setSkill(Player player, SwordSkillType type) {
        equippedSkill.put(player.getUniqueId(), type);
    }

    public SwordSkillType getSkill(Player player) {
        return equippedSkill.getOrDefault(player.getUniqueId(), SwordSkillType.HORIZONTAL);
    }

    public boolean isOnCooldown(Player player) {
        Long expiry = cooldownExpiry.get(player.getUniqueId());
        return expiry != null && expiry > System.currentTimeMillis();
    }

    public long getRemainingCooldownSeconds(Player player) {
        Long expiry = cooldownExpiry.get(player.getUniqueId());
        if (expiry == null) {
            return 0;
        }
        return Math.max(0, (expiry - System.currentTimeMillis()) / 1000);
    }

    /** Aktiviert den aktuell ausgerüsteten Sword Skill des Spielers. */
    public void activateSkill(Player player) {
        if (isOnCooldown(player)) {
            player.sendActionBar(ChatColor.RED + "Skill lädt noch " + getRemainingCooldownSeconds(player) + "s auf!");
            return;
        }

        SwordSkillType type = getSkill(player);
        cooldownExpiry.put(player.getUniqueId(), System.currentTimeMillis() + (type.getCooldownSeconds() * 1000L));

        switch (type) {
            case HORIZONTAL -> horizontal(player, type);
            case VERTICAL -> vertical(player, type);
            case SONIC_LEAP -> sonicLeap(player, type);
            case STARBURST_STREAM -> starburstStream(player, type);
        }

        player.sendActionBar(ChatColor.GOLD + "⚔ " + type.getDisplayName() + " ausgelöst!");
    }

    private void horizontal(Player player, SwordSkillType type) {
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1f, 1f);
        Location eye = player.getEyeLocation();
        for (LivingEntity target : nearbyTargets(player, 3.5)) {
            hit(player, target, type.getBonusDamage());
            player.getWorld().spawnParticle(Particle.SWEEP_ATTACK, target.getLocation().add(0, 1, 0), 3);
        }
    }

    private void vertical(Player player, SwordSkillType type) {
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_PLAYER_ATTACK_STRONG, 1f, 0.8f);
        for (LivingEntity target : nearbyTargets(player, 3.0)) {
            hit(player, target, type.getBonusDamage());
            target.setVelocity(target.getVelocity().add(new Vector(0, 0.5, 0)));
            player.getWorld().spawnParticle(Particle.CRIT, target.getLocation().add(0, 1, 0), 15);
        }
    }

    private void sonicLeap(Player player, SwordSkillType type) {
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_ENDER_DRAGON_FLAP, 1f, 1.5f);
        Vector direction = player.getLocation().getDirection().normalize().multiply(1.6).setY(0.35);
        player.setVelocity(direction);

        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            for (LivingEntity target : nearbyTargets(player, 3.0)) {
                hit(player, target, type.getBonusDamage());
                player.getWorld().spawnParticle(Particle.CLOUD, target.getLocation(), 10);
            }
        }, 4L);
    }

    private void starburstStream(Player player, SwordSkillType type) {
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_PLAYER_ATTACK_CRIT, 1f, 1f);
        int hits = 8; // vereinfachte Version der 16-Hit-Combo
        for (int i = 0; i < hits; i++) {
            final int delay = i * 2;
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                for (LivingEntity target : nearbyTargets(player, 3.5)) {
                    hit(player, target, type.getBonusDamage() / hits);
                    player.getWorld().spawnParticle(Particle.CRIT, target.getLocation().add(0, 1, 0), 5);
                }
            }, delay);
        }
    }

    private void hit(Player attacker, LivingEntity target, double damage) {
        if (target.equals(attacker)) {
            return;
        }
        target.damage(damage, attacker);
    }

    private java.util.List<LivingEntity> nearbyTargets(Player player, double range) {
        java.util.List<LivingEntity> result = new java.util.ArrayList<>();
        for (org.bukkit.entity.Entity entity : player.getNearbyEntities(range, range, range)) {
            if (entity instanceof LivingEntity living && isInFrontOf(player, living)) {
                result.add(living);
            }
        }
        return result;
    }

    private boolean isInFrontOf(Player player, LivingEntity target) {
        Vector toTarget = target.getLocation().toVector().subtract(player.getLocation().toVector()).normalize();
        Vector facing = player.getLocation().getDirection().normalize();
        return facing.dot(toTarget) > 0.4; // ca. 65-Grad-Kegel vor dem Spieler
    }
}
