package com.example.saocraft.listeners;

import com.example.saocraft.hp.HealthBarManager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityRegainHealthEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.entity.Player;

public class PlayerJoinQuitListener implements Listener {

    private final HealthBarManager healthBarManager;

    public PlayerJoinQuitListener(HealthBarManager healthBarManager) {
        this.healthBarManager = healthBarManager;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        healthBarManager.createBar(event.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        healthBarManager.removeBar(event.getPlayer());
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        healthBarManager.removeBar(event.getPlayer());
        healthBarManager.createBar(event.getPlayer());
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        healthBarManager.removeBar(event.getEntity());
    }

    @EventHandler
    public void onDamage(EntityDamageEvent event) {
        if (event.getEntity() instanceof Player player) {
            healthBarManager.updateBar(player);
        }
    }

    @EventHandler
    public void onRegain(EntityRegainHealthEvent event) {
        if (event.getEntity() instanceof Player player) {
            healthBarManager.updateBar(player);
        }
    }
}
