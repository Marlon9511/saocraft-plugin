package com.example.saocraft;

import com.example.saocraft.commands.DuelCommand;
import com.example.saocraft.commands.MenuCommand;
import com.example.saocraft.commands.SkillCommand;
import com.example.saocraft.duel.DuelListener;
import com.example.saocraft.duel.DuelManager;
import com.example.saocraft.gui.MenuListener;
import com.example.saocraft.hp.HealthBarManager;
import com.example.saocraft.listeners.PlayerJoinQuitListener;
import com.example.saocraft.listeners.SkillListener;
import com.example.saocraft.skills.SkillManager;
import org.bukkit.plugin.java.JavaPlugin;

public final class SaoCraftPlugin extends JavaPlugin {

    private HealthBarManager healthBarManager;
    private SkillManager skillManager;
    private DuelManager duelManager;

    @Override
    public void onEnable() {
        this.healthBarManager = new HealthBarManager(this);
        this.skillManager = new SkillManager(this);
        this.duelManager = new DuelManager(this);

        // Listener registrieren
        getServer().getPluginManager().registerEvents(new PlayerJoinQuitListener(healthBarManager), this);
        getServer().getPluginManager().registerEvents(new SkillListener(skillManager), this);
        getServer().getPluginManager().registerEvents(new DuelListener(duelManager), this);
        getServer().getPluginManager().registerEvents(new MenuListener(), this);

        // Commands registrieren
        getCommand("skill").setExecutor(new SkillCommand(skillManager));
        getCommand("duel").setExecutor(new DuelCommand(duelManager));
        getCommand("saomenu").setExecutor(new MenuCommand(skillManager, duelManager));

        // HP-Balken für bereits online befindliche Spieler starten (z.B. bei /reload)
        getServer().getOnlinePlayers().forEach(healthBarManager::createBar);
        healthBarManager.startUpdateTask();

        getLogger().info("SaoCraft aktiviert - Link Start!");
    }

    @Override
    public void onDisable() {
        if (healthBarManager != null) {
            healthBarManager.removeAllBars();
        }
        getLogger().info("SaoCraft deaktiviert - Logout.");
    }

    public HealthBarManager getHealthBarManager() {
        return healthBarManager;
    }

    public SkillManager getSkillManager() {
        return skillManager;
    }

    public DuelManager getDuelManager() {
        return duelManager;
    }
}
