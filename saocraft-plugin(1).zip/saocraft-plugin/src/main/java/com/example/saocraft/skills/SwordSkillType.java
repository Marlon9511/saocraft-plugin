package com.example.saocraft.skills;

import org.bukkit.ChatColor;

public enum SwordSkillType {

    HORIZONTAL("Horizontal", 3, 4.0, "Waagerechter Schwerthieb mit kurzer Reichweite."),
    VERTICAL("Vertical", 4, 5.0, "Vertikaler Hieb, der Gegner leicht nach oben schleudert."),
    SONIC_LEAP("Sonic Leap", 8, 6.0, "Ein schneller Sprung-Angriff nach vorn."),
    STARBURST_STREAM("Starburst Stream", 15, 9.0, "16-Hit-Combo mit massivem Schaden, lange Abklingzeit.");

    private final String displayName;
    private final int cooldownSeconds;
    private final double bonusDamage;
    private final String description;

    SwordSkillType(String displayName, int cooldownSeconds, double bonusDamage, String description) {
        this.displayName = displayName;
        this.cooldownSeconds = cooldownSeconds;
        this.bonusDamage = bonusDamage;
        this.description = description;
    }

    public String getDisplayName() {
        return displayName;
    }

    public int getCooldownSeconds() {
        return cooldownSeconds;
    }

    public double getBonusDamage() {
        return bonusDamage;
    }

    public String getDescription() {
        return description;
    }

    public String getColoredName() {
        return ChatColor.AQUA + displayName;
    }

    public static SwordSkillType fromArg(String arg) {
        return switch (arg.toLowerCase()) {
            case "horizontal" -> HORIZONTAL;
            case "vertical" -> VERTICAL;
            case "sonicleap", "sonic_leap", "sonic" -> SONIC_LEAP;
            case "starburst", "starburststream", "starburst_stream" -> STARBURST_STREAM;
            default -> null;
        };
    }
}
