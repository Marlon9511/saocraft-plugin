package com.example.saocraft.hp;

import com.example.saocraft.SaoCraftPlugin;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Erzeugt pro Spieler einen unsichtbaren ArmorStand knapp über dem Kopf,
 * dessen Custom-Name als HP-Balken im SAO-Stil ("❤ 18.0 / 20.0") dient.
 */
public class HealthBarManager {

    private final SaoCraftPlugin plugin;
    private final Map<UUID, ArmorStand> bars = new HashMap<>();
    private BukkitTask task;

    public HealthBarManager(SaoCraftPlugin plugin) {
        this.plugin = plugin;
    }

    public void createBar(Player player) {
        if (bars.containsKey(player.getUniqueId())) {
            return;
        }
        Location loc = player.getLocation().clone().add(0, 2.3, 0);
        ArmorStand stand = (ArmorStand) player.getWorld().spawnEntity(loc, EntityType.ARMOR_STAND);
        stand.setInvisible(true);
        stand.setMarker(true);
        stand.setGravity(false);
        stand.setCustomNameVisible(true);
        stand.setPersistent(false);
        stand.setSmall(true);
        stand.setCanTick(false);
        bars.put(player.getUniqueId(), stand);
        updateBar(player);
    }

    public void removeBar(Player player) {
        ArmorStand stand = bars.remove(player.getUniqueId());
        if (stand != null) {
            stand.remove();
        }
    }

    public void removeAllBars() {
        bars.values().forEach(ArmorStand::remove);
        bars.clear();
        if (task != null) {
            task.cancel();
        }
    }

    public void updateBar(Player player) {
        ArmorStand stand = bars.get(player.getUniqueId());
        if (stand == null) {
            return;
        }
        double health = player.getHealth();
        double max = player.getAttribute(Attribute.GENERIC_MAX_HEALTH) != null
                ? player.getAttribute(Attribute.GENERIC_MAX_HEALTH).getValue()
                : 20.0;

        String barColor = health > max * 0.5 ? ChatColor.GREEN.toString()
                : health > max * 0.2 ? ChatColor.YELLOW.toString()
                : ChatColor.RED.toString();

        String name = ChatColor.GOLD + player.getName() + ChatColor.GRAY + "  "
                + barColor + "❤ " + String.format("%.1f", health) + " / " + String.format("%.1f", max);
        stand.setCustomName(name);
    }

    /** Läuft alle 2 Ticks: hält den Balken über dem Kopf des Spielers, auch bei Bewegung. */
    public void startUpdateTask() {
        task = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            for (Player player : plugin.getServer().getOnlinePlayers()) {
                ArmorStand stand = bars.get(player.getUniqueId());
                if (stand == null) {
                    continue;
                }
                Location target = player.getLocation().clone().add(0, 2.3, 0);
                stand.teleport(target);
                updateBar(player);
            }
        }, 2L, 2L);
    }
}
