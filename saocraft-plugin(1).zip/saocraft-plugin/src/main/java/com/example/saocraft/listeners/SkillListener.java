package com.example.saocraft.listeners;

import com.example.saocraft.skills.SkillManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.Event.Result;
import org.bukkit.inventory.ItemStack;
import org.bukkit.Material;
import org.bukkit.event.block.Action;

public class SkillListener implements Listener {

    private final SkillManager skillManager;

    public SkillListener(SkillManager skillManager) {
        this.skillManager = skillManager;
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        Player player = event.getPlayer();
        if (!player.isSneaking()) {
            return;
        }
        ItemStack item = player.getInventory().getItemInMainHand();
        if (!isSword(item.getType())) {
            return;
        }
        event.setUseItemInHand(Result.DENY);
        skillManager.activateSkill(player);
    }

    private boolean isSword(Material material) {
        return material.name().endsWith("_SWORD");
    }
}
