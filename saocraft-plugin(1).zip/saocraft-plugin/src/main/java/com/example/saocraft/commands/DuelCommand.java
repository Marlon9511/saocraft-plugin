package com.example.saocraft.commands;

import com.example.saocraft.duel.DuelManager;
import org.bukkit.ChatColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class DuelCommand implements CommandExecutor {

    private final DuelManager duelManager;

    public DuelCommand(DuelManager duelManager) {
        this.duelManager = duelManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Nur Spieler können diesen Befehl nutzen.");
            return true;
        }

        if (args.length == 0) {
            player.sendMessage(ChatColor.YELLOW + "Nutzung: /duel <spieler> | accept | decline | leave");
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "accept" -> duelManager.acceptDuel(player);
            case "decline" -> duelManager.declineDuel(player);
            case "leave" -> duelManager.leaveDuel(player);
            default -> {
                Player target = Bukkit.getPlayerExact(args[0]);
                if (target == null || !target.isOnline()) {
                    player.sendMessage(ChatColor.RED + "Spieler nicht gefunden.");
                    return true;
                }
                if (target.equals(player)) {
                    player.sendMessage(ChatColor.RED + "Du kannst dich nicht selbst herausfordern.");
                    return true;
                }
                duelManager.requestDuel(player, target);
            }
        }
        return true;
    }
}
