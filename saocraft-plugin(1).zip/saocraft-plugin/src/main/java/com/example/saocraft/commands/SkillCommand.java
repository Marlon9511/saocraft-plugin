package com.example.saocraft.commands;

import com.example.saocraft.skills.SkillManager;
import com.example.saocraft.skills.SwordSkillType;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SkillCommand implements CommandExecutor {

    private final SkillManager skillManager;

    public SkillCommand(SkillManager skillManager) {
        this.skillManager = skillManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Nur Spieler können diesen Befehl nutzen.");
            return true;
        }

        if (args.length == 0 || args[0].equalsIgnoreCase("list")) {
            player.sendMessage(ChatColor.GOLD + "=== Verfügbare Sword Skills ===");
            for (SwordSkillType type : SwordSkillType.values()) {
                player.sendMessage(type.getColoredName() + ChatColor.GRAY + " - " + type.getDescription());
            }
            player.sendMessage(ChatColor.YELLOW + "Aktivierung: Schleichen + Rechtsklick mit Schwert");
            return true;
        }

        SwordSkillType type = SwordSkillType.fromArg(args[0]);
        if (type == null) {
            player.sendMessage(ChatColor.RED + "Unbekannter Skill. Nutze /skill list");
            return true;
        }

        skillManager.setSkill(player, type);
        player.sendMessage(ChatColor.GREEN + "Sword Skill gewechselt zu " + type.getColoredName());
        return true;
    }
}
