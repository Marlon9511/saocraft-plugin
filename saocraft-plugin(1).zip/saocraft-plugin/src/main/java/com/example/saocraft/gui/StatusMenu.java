package com.example.saocraft.gui;

import com.example.saocraft.duel.DuelManager;
import com.example.saocraft.skills.SkillManager;
import com.example.saocraft.skills.SwordSkillType;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class StatusMenu {

    public static final String TITLE = ChatColor.DARK_AQUA + "" + ChatColor.BOLD + "Status" + ChatColor.RESET
            + ChatColor.GRAY + "  —  Sword Art Online Menü";

    public static Inventory build(Player player, SkillManager skillManager, DuelManager duelManager) {
        Inventory inv = org.bukkit.Bukkit.createInventory(null, 27, TITLE);

        // Rahmen
        ItemStack filler = namedItem(Material.CYAN_STAINED_GLASS_PANE, " ", null);
        for (int i = 0; i < 27; i++) {
            inv.setItem(i, filler);
        }

        // Spieler-Kopf / Name
        double health = player.getHealth();
        double max = player.getAttribute(Attribute.GENERIC_MAX_HEALTH) != null
                ? player.getAttribute(Attribute.GENERIC_MAX_HEALTH).getValue() : 20.0;

        List<String> playerLore = new ArrayList<>();
        playerLore.add(ChatColor.GRAY + "Level: " + ChatColor.WHITE + player.getLevel());
        playerLore.add(ChatColor.RED + "HP: " + ChatColor.WHITE + String.format("%.1f / %.1f", health, max));
        playerLore.add(ChatColor.YELLOW + "Hunger: " + ChatColor.WHITE + player.getFoodLevel() + " / 20");
        inv.setItem(4, namedItem(Material.PLAYER_HEAD, ChatColor.GOLD + player.getName(), playerLore));

        // Ausgerüsteter Sword Skill
        SwordSkillType equipped = skillManager.getSkill(player);
        List<String> skillLore = new ArrayList<>();
        skillLore.add(ChatColor.GRAY + equipped.getDescription());
        skillLore.add("");
        boolean onCooldown = skillManager.isOnCooldown(player);
        skillLore.add(onCooldown
                ? ChatColor.RED + "Cooldown: " + skillManager.getRemainingCooldownSeconds(player) + "s"
                : ChatColor.GREEN + "Bereit!");
        inv.setItem(11, namedItem(Material.NETHERITE_SWORD, ChatColor.AQUA + "Ausgerüstet: " + equipped.getDisplayName(), skillLore));

        // Übersicht aller Skills
        int[] slots = {12, 13, 14, 15};
        SwordSkillType[] types = SwordSkillType.values();
        for (int i = 0; i < types.length; i++) {
            SwordSkillType type = types[i];
            List<String> lore = new ArrayList<>();
            lore.add(ChatColor.GRAY + type.getDescription());
            lore.add(ChatColor.DARK_GRAY + "Cooldown: " + type.getCooldownSeconds() + "s");
            lore.add(ChatColor.DARK_GRAY + "Bonus-Schaden: " + type.getBonusDamage());
            lore.add("");
            lore.add(type == equipped ? ChatColor.GREEN + "✔ Ausgerüstet"
                    : ChatColor.YELLOW + "/skill " + type.name().toLowerCase().replace("_", ""));
            inv.setItem(slots[i], namedItem(Material.IRON_SWORD, type.getColoredName(), lore));
        }

        // Duell-Status
        Player opponent = duelManager.getOpponent(player);
        List<String> duelLore = new ArrayList<>();
        if (opponent != null) {
            duelLore.add(ChatColor.RED + "Im Duell gegen " + opponent.getName());
            duelLore.add(ChatColor.GRAY + "/duel leave" + ChatColor.DARK_GRAY + " zum Verlassen");
        } else {
            duelLore.add(ChatColor.GREEN + "Kein aktives Duell");
            duelLore.add(ChatColor.GRAY + "/duel <spieler>" + ChatColor.DARK_GRAY + " zum Herausfordern");
        }
        inv.setItem(22, namedItem(Material.DIAMOND_SWORD, ChatColor.LIGHT_PURPLE + "Duell-Status", duelLore));

        return inv;
    }

    private static ItemStack namedItem(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        if (lore != null) {
            meta.setLore(lore);
        }
        item.setItemMeta(meta);
        return item;
    }
}
