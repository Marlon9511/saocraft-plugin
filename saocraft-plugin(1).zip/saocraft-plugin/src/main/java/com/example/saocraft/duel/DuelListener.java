package com.example.saocraft.duel;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;

public class DuelListener implements Listener {

    private final DuelManager duelManager;

    public DuelListener(DuelManager duelManager) {
        this.duelManager = duelManager;
    }

    /**
     * Statt den Spieler wirklich sterben zu lassen, wird der Schaden abgefangen,
     * sobald er tödlich wäre - dann gilt das Duell als verloren.
     */
    @EventHandler(priority = EventPriority.HIGH)
    public void onDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) {
            return;
        }
        if (!duelManager.isInDuel(player)) {
            return;
        }

        double resultingHealth = player.getHealth() - event.getFinalDamage();
        if (resultingHealth > 0) {
            return;
        }

        event.setCancelled(true);
        Player opponent = duelManager.getOpponent(player);
        if (opponent != null) {
            duelManager.endDuel(player, opponent, opponent);
        }
    }
}
