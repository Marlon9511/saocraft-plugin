package com.example.saocraft.commands;

import com.example.saocraft.duel.DuelManager;
import com.example.saocraft.gui.StatusMenu;
import com.example.saocraft.skills.SkillManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class MenuCommand implements CommandExecutor {

    private final SkillManager skillManager;
    private final DuelManager duelManager;

    public MenuCommand(SkillManager skillManager, DuelManager duelManager) {
        this.skillManager = skillManager;
        this.duelManager = duelManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Nur Spieler können diesen Befehl nutzen.");
            return true;
        }
        player.openInventory(StatusMenu.build(player, skillManager, duelManager));
        return true;
    }
}
